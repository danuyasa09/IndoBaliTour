<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title>Indo Bali Tour | Blogs & News</title>
        @fonts
        @vite(['resources/css/app.css', 'resources/js/app.js'])
        <!-- Alpine JS for light interactivity like mobile menu and dropdowns -->
        <script defer src="https://cdn.jsdelivr.net/npm/alpinejs@3.x.x/dist/cdn.min.js"></script>
    </head>
    <body class="bg-[#FDFDFC] text-gray-900 antialiased font-sans">
        <x-navbar />
              <x-floating_contactUs />

        <!-- Hero Section -->
        <div class="relative h-[400px] md:h-[550px] w-full bg-cover bg-center" style="background-image: url('https://images.unsplash.com/photo-1537996194471-e657df975ab4?q=80&w=1200&auto=format&fit=crop');">
            <div class="absolute inset-0 bg-black/50 flex items-center justify-center">
                <div class="text-center text-white px-4">
                    <h1 class="text-4xl md:text-5xl font-bold tracking-wide mb-4">Blogs & News</h1>
                    <p class="text-sm md:text-base text-gray-200 max-w-md mx-auto">
                        Temukan tips perjalanan, cerita budaya, dan rekomendasi destinasi terbaik dari pemandu lokal kami.
                    </p>
                </div>
            </div>
        </div>

        <!-- Blog Grid -->
        <div class="max-w-7xl mx-auto px-4 py-16">
            <div class="grid grid-cols-1 md:grid-cols-3 gap-8">
                @foreach ($blogs as $slug => $item)
                <div class="bg-white rounded-xl shadow-sm border border-gray-100 overflow-hidden flex flex-col justify-between group">
                    <div class="relative overflow-hidden h-48">
                        <img src="{{ $item['image'] }}" alt="{{ $item['title'] }}" class="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300">
                    </div>
                    
                    <div class="p-6 flex-1 flex flex-col justify-between">
                        <div>
                            <div class="flex items-center space-x-2 text-[10px] text-gray-400 font-semibold mb-3">
                                <span class="uppercase tracking-wider">{{ $item['category'] }}</span>
                                <span>•</span>
                                <span>{{ $item['date'] }}</span>
                            </div>
                            <h3 class="text-lg font-bold text-gray-900 mb-2 leading-snug group-hover:text-brand-red transition-colors">
                                {{ $item['title'] }}
                            </h3>
                            <p class="text-gray-500 text-xs leading-relaxed mb-4">
                                {{ $item['excerpt'] }}
                            </p>
                        </div>
                        
                        <a href="{{ route('blog.show', $slug) }}" class="inline-flex items-center text-xs font-bold text-[#7A0C16] hover:text-[#5A0810] transition-colors">
                            Baca Selengkapnya <span class="ml-1">&rarr;</span>
                        </a>
                    </div>
                </div>
                @endforeach
            </div>
        </div>

        <!-- Newsletter Section -->
        <div class="bg-gray-50 py-16 border-t border-b border-gray-100">
            <div class="max-w-4xl mx-auto px-4 text-center">
                <h2 class="text-2xl md:text-3xl font-bold text-gray-900 mb-4">Dapatkan Informasi Promosi & Tips Menarik</h2>
                <p class="text-xs text-gray-500 mb-8 max-w-md mx-auto">
                    Berlangganan buletin mingguan kami untuk panduan liburan terlengkap ke Bali langsung di email Anda.
                </p>
                <div class="flex flex-col sm:flex-row justify-center items-center gap-3">
                    <input type="email" placeholder="Alamat Email Anda" class="w-full sm:w-80 px-4 py-3 border border-gray-200 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-brand-red">
                    <button class="w-full sm:w-auto bg-[#7A0C16] hover:bg-[#5a0810] text-white py-3 px-6 rounded-lg text-sm font-semibold transition-colors duration-200">
                        Subscribe
                    </button>
                </div>
            </div>
        </div>

        <x-footer />
    </body>
</html>
